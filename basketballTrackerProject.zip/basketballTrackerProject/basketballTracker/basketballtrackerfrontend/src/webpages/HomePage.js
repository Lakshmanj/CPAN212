import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const HomePage = ({ username }) => {
    const [scores, setScores] = useState([]);
    const [formData, setFormData] = useState({
        league: '',
        season: '',
        team: '',
        gameType: 'all',
        date: '',
    });
    const navigate = useNavigate();

    useEffect(() => {
        const fetchScores = async () => {
            try {
                const token = localStorage.getItem('token'); 
                const response = await axios.get('http://localhost:8000/api/scores', {
                    headers: {
                        Authorization: `Bearer ${token}`, 
                        'x-apisports-key': process.env.API_KEY, 
                    },
                    params: {
                        league: formData.league,
                        season: formData.season,
                        team: formData.team,
                        gameType: formData.gameType,
                        date: formData.date, 
                    },
                });
                console.log('Scores fetched:', response.data);
                setScores(response.data);
            } catch (error) {
                console.error('Error fetching scores:', error);
            }
        };
        fetchScores();
    }, [formData.league, formData.season, formData.team, formData.gameType, formData.date]); 

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSearch = async () => {
        try {
            const token = localStorage.getItem('token'); 
            const response = await axios.get('http://localhost:8000/api/scores', {
                headers: {
                    Authorization: `Bearer ${token}`, 
                    'x-apisports-key': process.env.API_KEY, 
                },
                params: {
                    league: formData.league,
                    season: formData.season,
                    team: formData.team,
                    gameType: formData.gameType,
                    date: formData.date, 
                },
            });
            console.log('Filtered scores:', response.data);
            setScores(response.data);
        } catch (error) {
            console.error('Error fetching filtered scores:', error);
        }
    };

    const handleSettingsClick = () => {
        navigate('/settings');
    };

    const handleLogOutClick = () => {
        navigate('/');
    };

    return (
        <div style={styles.pageContainer}>
            <h1 style={styles.title}>Basketball Score Tracker</h1>
            <h2 style={styles.welcomeMessage}>Welcome, {username}</h2>

            <div style={styles.searchContainer}>
                <form style={styles.form}>
                    <div style={styles.inputGroup}>
                        <label>League:</label>
                        <input
                            type="text"
                            name="league"
                            value={formData.league}
                            onChange={handleChange}
                            style={styles.input}
                            placeholder="Enter league"
                        />
                    </div>
                    <div style={styles.inputGroup}>
                        <label>Season:</label>
                        <input
                            type="text"
                            name="season"
                            value={formData.season}
                            onChange={handleChange}
                            style={styles.input}
                            placeholder="Enter season"
                        />
                    </div>
                    <div style={styles.inputGroup}>
                        <label>Team:</label>
                        <input
                            type="text"
                            name="team"
                            value={formData.team}
                            onChange={handleChange}
                            style={styles.input}
                            placeholder="Enter team name"
                        />
                    </div>
                    <div style={styles.inputGroup}>
                        <label>Game Type:</label>
                        <select
                            name="gameType"
                            value={formData.gameType}
                            onChange={handleChange}
                            style={styles.select}
                        >
                            <option value="all">All Games</option>
                            <option value="live">Live Games</option>
                        </select>
                    </div>
                    <div style={styles.inputGroup}>
                        <label>Date:</label>
                        <input
                            type="text"
                            name="date"
                            value={formData.date}
                            onChange={handleChange}
                            style={styles.input}
                            placeholder="Enter date (YYYY-MM-DD)"
                        />
                    </div>
                    <button type="button" style={styles.searchButton} onClick={handleSearch}>
                        Play Ball!
                    </button>
                </form>
            </div>

            {scores.length > 0 && (
                <div style={styles.resultsContainer}>
                    <h3>Search Results</h3>
                    <ul>
                        {scores.map((game) => (
                            <li key={game.id}>
                                {game.teams.home.name} vs {game.teams.away.name} - {game.scores.home.total} : {game.scores.away.total}
                            </li>
                        ))}
                    </ul>
                </div>
            )}

            <button style={styles.settingsButton} onClick={handleSettingsClick}>
                Account Settings
            </button>
            <button style={styles.logOutButton} onClick={handleLogOutClick}>
                Log Out
            </button>
        </div>
    );
};

const styles = {
    pageContainer: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        minHeight: '100vh',
        fontFamily: 'Arial, sans-serif',
        backgroundColor: 'teal',
        padding: '20px',
        position: 'relative',
    },
    title: {
        fontSize: '35px',
        fontWeight: 'bold',
        color: 'white',
    },
    welcomeMessage: {
        fontSize: '24px',
        color: 'white',
        marginBottom: '20px',
    },
    searchContainer: {
        backgroundColor: 'orange',
        padding: '20px',
        borderRadius: '8px',
        width: '350px',
        textAlign: 'center',
        boxShadow: '0px 0px 5px rgba(0, 0, 0, 0.2)',
        marginBottom: '20px',
    },
    form: {
        display: 'flex',
        flexDirection: 'column',
    },
    inputGroup: {
        marginBottom: '10px',
        textAlign: 'left',
    },
    input: {
        width: '100%',
        padding: '8px',
        borderRadius: '4px',
        border: '1px solid #ccc',
    },
    select: {
        width: '100%',
        padding: '8px',
        borderRadius: '4px',
        border: '1px solid #ccc',
    },
    searchButton: {
        padding: '10px',
        width: '100%',
        backgroundColor: '#333',
        color: 'white',
        fontWeight: 'bold',
        borderRadius: '4px',
        cursor: 'pointer',
    },
    resultsContainer: {
        backgroundColor: 'lime',
        padding: '20px',
        borderRadius: '8px',
        width: '350px',
        textAlign: 'center',
        boxShadow: '0px 0px 5px rgba(0, 0, 0, 0.2)',
    },
    settingsButton: {
        position: 'absolute',
        bottom: '60px',
        right: '20px',
        padding: '10px',
        backgroundColor: '#555',
        color: 'white',
        fontWeight: 'bold',
        borderRadius: '4px',
        cursor: 'pointer',
    },
    logOutButton: {
        position: 'absolute',
        bottom: '20px',
        right: '20px',
        padding: '10px',
        backgroundColor: '#555',
        color: 'white',
        fontWeight: 'bold',
        borderRadius: '4px',
        cursor: 'pointer',
    },
};

export default HomePage;
